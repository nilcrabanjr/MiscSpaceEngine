#pragma once
#include <iostream>
#include <vector>
#include <map>
#include <string>
#include "Tile.h"

class Tileset
{
	public:
		// Getters
		std::vector<Tile> getTiles();
		int getTilesetWidth();
		int getTilesetHeight();
		std::map<int, std::string> getTextureMap();

		// Setters
		void setTilesetWidth(int);
		void setTilesetHeight(int);

		// Functions
		void addTileToEnd(Tile);
		void replaceTile(int, Tile);

		// Graphics
		void addTextureMap(int, std::string);

		// Debug
		void printTileset();
		void printTextureMap();

	private:
		std::vector<Tile> tiles;
		std::map<int, std::string> textureMap;
		int tilesetWidth;
		int tilesetHeight;
};
