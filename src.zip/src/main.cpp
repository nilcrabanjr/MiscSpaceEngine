#include "raylib.h"
#include "resource_dir.h"
#include "Tile.h"
#include "Tileset.h"
#include "TextureManager.h"
#include <iostream>

int main ()
{
	TextureManager Texture_Manager;
	Tile test_tile1(1, true, true, false, false, false, 1);
	Tile test_tile2(2, true, true, false, false, false, 2);
	Tile test_tile3(3, true, true, false, false, false, 2);
	Tile test_tile4(4, true, true, false, false, false, 1);
	Tileset test_tileset;
	test_tileset.addTileToEnd(test_tile1); test_tileset.addTileToEnd(test_tile2); test_tileset.addTileToEnd(test_tile3); test_tileset.addTileToEnd(test_tile4);
	test_tileset.addTextureMap(1, "resources/red.png"); test_tileset.addTextureMap(2, "resources/green.png");
	test_tileset.printTileset();
	// Window setup
	SetTraceLogLevel(LOG_ERROR);
	const int width = 1280; const int height = 760;
	InitWindow(width, height, "MiscSpaceEngine");
	Texture_Manager.initTileset(test_tileset);
	SetTargetFPS(60);

	while (!WindowShouldClose()) {
		BeginDrawing();
		Texture_Manager.renderTileset(test_tileset);
		EndDrawing();
	}

	CloseWindow();
	return 0;
}
