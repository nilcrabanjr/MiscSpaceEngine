#pragma once
#include <iostream>
#include "raylib.h"
#include "Tileset.h"
#include <vector>

class TextureManager
{
	public: 
		void initTileset(Tileset);
		void renderTileset(Tileset);

	private:
		std::vector<Texture2D> textures2d;
};

