#include "TextureManager.h"
#include <iostream>

void TextureManager::initTileset(Tileset target) {
    for (const auto& [id, location] : target.getTextureMap()) {
        std::cout << "ID: " << id << ", Location: " << location << std::endl;
        Texture2D texture = LoadTexture(location.c_str());
        textures2d.push_back(texture);
    }
}

void TextureManager::renderTileset(Tileset target) {
    int x = 0;

    for (const Tile& tile : target.getTiles()) {
        int texIndex = tile.getTileTextureID() - 1;

        if (texIndex >= 0 && texIndex < textures2d.size()) {
            DrawTexture(textures2d[texIndex], x * 64, 0, WHITE);
        }

        x++;
    }
}


