#include "Tileset.h"
#include <iostream>

// Getters
std::vector<Tile> Tileset::getTiles() {
	return tiles;
}
int Tileset::getTilesetWidth() {
	return tilesetWidth;
}
int Tileset::getTilesetHeight() {
	return tilesetHeight;
}

std::map<int, std::string> Tileset::getTextureMap() {
	return textureMap;
}

// Setters
void Tileset::setTilesetWidth(int option) {
	tilesetWidth = option;
}
void Tileset::setTilesetHeight(int option) {
	tilesetHeight = option;
}

// Functions
void Tileset::addTileToEnd(Tile option) {
	tiles.push_back(option);
}

void Tileset::replaceTile(int pos, Tile option) {
	tiles[pos] = option;
}

// Graphics
void Tileset::addTextureMap(int id, std::string location) {
	textureMap.insert({id, location});
}

// Debug
void Tileset::printTileset() {
	for (Tile i : tiles) {
		i.printTile();
		std::cout << std::endl;
	}
}

void Tileset::printTextureMap() {
	for (const auto& [id, location] : textureMap) {
		std::cout << "ID: " << id << ", Location: " << location << std::endl;
	}
}